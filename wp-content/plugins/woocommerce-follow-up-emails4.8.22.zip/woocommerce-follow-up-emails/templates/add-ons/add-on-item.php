<div>
	<h3><a href="<?php echo esc_url( $addon->url ); ?>" target="_blank"><?php echo esc_html( $addon->name ); ?></a></h3>

	<p><?php echo esc_html( $addon->description ); ?></p>/
</div>