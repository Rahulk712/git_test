jQuery(document).ready(function($) {

    if ( typeof FUE == 'undefined' ) {
        return;
    }

    init_fue_select();
    init_fue_customer_search();
} );