<p class="form-field">
	<span id="test_email_order">
		<?php esc_html_e( 'with Order Number: ', 'follow_up_emails' ); ?>
		<input type="number" id="order_id" placeholder="e.g. 105" size="5" class="test-email-field" min="1" />
	</span>
</p>
