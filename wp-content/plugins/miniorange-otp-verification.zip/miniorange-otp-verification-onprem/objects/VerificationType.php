<?php


namespace OTP\Objects;

class VerificationType
{
    const EMAIL = "\145\155\141\x69\x6c";
    const PHONE = "\160\x68\157\x6e\x65";
    const BOTH = "\142\x6f\x74\x68";
    const EXTERNAL = "\x65\170\x74\145\x72\156\141\x6c";
    const TEST = "\164\145\x73\x74";
}
