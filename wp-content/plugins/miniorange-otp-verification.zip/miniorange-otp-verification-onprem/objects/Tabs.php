<?php


namespace OTP\Objects;

final class Tabs
{
    const FORMS = "\x66\x6f\x72\155\163";
    const OTP_SETTINGS = "\x6f\164\x70\137\x73\x65\x74\x74\x69\156\x67\163";
    const ACCOUNT = "\x61\143\x63\157\165\156\x74";
    const SMS_EMAIL_CONFIG = "\163\x6d\x73\137\x65\x6d\141\x69\154\x5f\143\157\x6e\146\x69\x67";
    const MESSAGES = "\x6d\x65\x73\163\141\147\145\163";
    const DESIGN = "\144\145\x73\151\x67\x6e";
    const PRICING = "\160\x72\x69\x63\x69\x6e\147";
    const ADD_ONS = "\141\144\144\x6f\156\163";
}
