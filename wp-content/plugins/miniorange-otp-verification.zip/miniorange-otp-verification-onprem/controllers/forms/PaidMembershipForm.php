<?php


use OTP\Handler\Forms\PaidMembershipForm;
$Sw = PaidMembershipForm::instance();
$S5 = $Sw->isFormEnabled() ? "\x63\150\145\x63\153\x65\144" : '';
$sT = $S5 == "\143\x68\145\143\153\145\144" ? '' : "\x68\x69\144\144\145\x6e";
$Z2 = $Sw->getOtpTypeEnabled();
$HM = $Sw->getPhoneHTMLTag();
$Jk = $Sw->getEmailHTMLTag();
$Ra = $Sw->getFormName();
get_plugin_form_link($Sw->getFormDocuments());
include MOV_DIR . "\x76\x69\x65\167\163\x2f\x66\157\162\155\163\x2f\x50\x61\x69\144\x4d\x65\155\x62\145\x72\x73\x68\151\x70\106\x6f\162\155\56\x70\x68\160";
