<?php


use OTP\Handler\Forms\WooCommerceSocialLoginForm;
$Sw = WooCommerceSocialLoginForm::instance();
$jo = (bool) $Sw->isFormEnabled() ? "\143\150\145\143\153\145\144" : '';
$Ra = $Sw->getFormName();
get_plugin_form_link($Sw->getFormDocuments());
include MOV_DIR . "\x76\x69\145\167\x73\x2f\146\157\162\155\163\x2f\127\157\157\x43\x6f\155\x6d\x65\162\x63\x65\x53\x6f\143\151\141\x6c\x4c\157\x67\151\x6e\106\x6f\x72\x6d\56\x70\150\160";
