<?php


use OTP\Handler\Forms\PieRegistrationForm;
$Sw = PieRegistrationForm::instance();
$wp = $Sw->isFormEnabled() ? "\143\x68\x65\143\x6b\145\144" : '';
$Xv = $wp == "\143\150\x65\x63\x6b\x65\x64" ? '' : "\150\x69\x64\x64\145\x6e";
$e2 = $Sw->getOtpTypeEnabled();
$gB = $Sw->getPhoneKeyDetails();
$AK = $Sw->getPhoneHTMLTag();
$Gr = $Sw->getEmailHTMLTag();
$fr = $Sw->getBothHTMLTag();
$Ra = $Sw->getFormName();
get_plugin_form_link($Sw->getFormDocuments());
include MOV_DIR . "\166\x69\145\167\163\57\x66\x6f\162\x6d\163\57\x50\151\145\122\145\147\151\163\x74\x72\141\164\151\157\156\106\157\x72\155\56\x70\150\x70";
