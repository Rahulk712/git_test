<?php


use OTP\Handler\Forms\RealEstate7;
$Sw = RealEstate7::instance();
$Lo = $Sw->isFormEnabled() ? "\143\150\x65\x63\153\145\144" : '';
$qq = $Lo == "\x63\150\145\143\153\145\144" ? '' : "\150\x69\144\x64\145\x6e";
$h5 = $Sw->getOtpTypeEnabled();
$o6 = $Sw->getPhoneHTMLTag();
$ZE = $Sw->getEmailHTMLTag();
$Ra = $Sw->getFormName();
get_plugin_form_link($Sw->getFormDocuments());
include MOV_DIR . "\166\x69\145\167\163\57\x66\157\162\155\163\57\122\x65\141\154\x45\x73\164\141\x74\145\x37\x2e\x70\x68\x70";
