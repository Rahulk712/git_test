<?php


use OTP\Handler\Forms\RealesWPTheme;
$Sw = RealesWPTheme::instance();
$U3 = $Sw->isFormEnabled() ? "\x63\150\145\x63\153\145\x64" : '';
$RJ = $U3 == "\143\x68\145\x63\x6b\145\144" ? '' : "\150\x69\x64\x64\145\x6e";
$Ll = $Sw->getOtpTypeEnabled();
$Yf = $Sw->getPhoneHTMLTag();
$rZ = $Sw->getEmailHTMLTag();
$Ra = $Sw->getFormName();
get_plugin_form_link($Sw->getFormDocuments());
include MOV_DIR . "\x76\x69\x65\167\x73\57\x66\157\x72\x6d\163\57\122\145\x61\154\145\163\127\x50\x54\x68\x65\155\x65\56\x70\150\x70";
