<?php


use OTP\Handler\Forms\GravityForm;
$Sw = GravityForm::instance();
$R4 = $Sw->isFormEnabled() ? "\143\150\145\143\x6b\145\144" : '';
$xx = $R4 == "\143\x68\x65\143\x6b\x65\x64" ? '' : "\150\x69\x64\144\x65\x6e";
$jf = $Sw->getOtpTypeEnabled();
$UL = admin_url() . "\141\144\155\151\x6e\56\160\x68\160\x3f\x70\x61\147\145\x3d\x67\x66\137\145\144\151\x74\x5f\146\x6f\x72\155\163";
$Ai = $Sw->getFormDetails();
$Ik = $Sw->getEmailHTMLTag();
$Wj = $Sw->getPhoneHTMLTag();
$Ra = $Sw->getFormName();
$lq = $Sw->getButtonText();
get_plugin_form_link($Sw->getFormDocuments());
include MOV_DIR . "\166\151\x65\167\163\x2f\146\x6f\162\x6d\163\57\107\162\x61\166\151\x74\x79\x46\157\162\x6d\56\160\x68\x70";
