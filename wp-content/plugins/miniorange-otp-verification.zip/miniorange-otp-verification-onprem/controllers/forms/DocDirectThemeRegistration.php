<?php


use OTP\Handler\Forms\DocDirectThemeRegistration;
$Sw = DocDirectThemeRegistration::instance();
$oU = $Sw->isFormEnabled() ? "\143\x68\x65\143\153\145\x64" : '';
$L3 = $oU == "\x63\x68\x65\143\x6b\x65\x64" ? '' : "\x68\x69\144\144\x65\156";
$dv = $Sw->getOtpTypeEnabled();
$Q9 = $Sw->getPhoneHTMLTag();
$Sm = $Sw->getEmailHTMLTag();
$Ra = $Sw->getFormName();
get_plugin_form_link($Sw->getFormDocuments());
include MOV_DIR . "\166\x69\145\167\x73\57\x66\x6f\x72\x6d\x73\57\x44\157\143\x44\151\x72\x65\143\x74\124\150\x65\x6d\145\122\x65\x67\x69\163\164\162\141\164\151\157\x6e\x2e\160\x68\160";
