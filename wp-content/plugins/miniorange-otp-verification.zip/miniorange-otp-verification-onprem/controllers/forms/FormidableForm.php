<?php


use OTP\Handler\Forms\FormidableForm;
$Sw = FormidableForm::instance();
$w5 = $Sw->isFormEnabled() ? "\x63\x68\145\143\x6b\145\x64" : '';
$YL = $w5 == "\143\x68\x65\143\153\145\144" ? '' : "\x68\151\x64\144\x65\x6e";
$jX = $Sw->getOtpTypeEnabled();
$Ax = admin_url() . "\x61\x64\155\151\x6e\x2e\x70\150\x70\x3f\160\141\147\145\75\x66\157\x72\x6d\x69\144\141\x62\x6c\145";
$KC = $Sw->getFormDetails();
$vI = $Sw->getPhoneHTMLTag();
$OY = $Sw->getEmailHTMLTag();
$YG = $Sw->getButtonText();
$Ra = $Sw->getFormName();
get_plugin_form_link($Sw->getFormDocuments());
include MOV_DIR . "\x76\151\x65\167\x73\57\x66\x6f\x72\155\163\x2f\x46\x6f\x72\x6d\151\x64\x61\x62\154\145\x46\x6f\x72\x6d\56\x70\x68\160";
