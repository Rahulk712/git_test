<?php


use OTP\Helper\MoUtility;
$cH = get_mo_option("\x62\154\x6f\x63\153\145\x64\x5f\144\157\155\141\x69\x6e\163");
$Rg = get_mo_option("\142\154\x6f\x63\153\x65\x64\x5f\160\150\157\x6e\x65\x5f\x6e\165\x6d\142\x65\x72\x73");
$NT = get_mo_option("\x73\150\157\x77\x5f\162\145\155\141\151\x6e\x69\x6e\x67\137\164\x72\141\156\x73") ? "\x63\x68\x65\x63\x6b\145\144" : '';
$wR = get_mo_option("\x73\150\x6f\x77\x5f\x64\162\x6f\x70\144\157\x77\156\137\157\156\137\x66\157\162\x6d") ? "\x63\x68\x65\143\x6b\x65\x64" : '';
$JD = get_mo_option("\157\x74\x70\137\x6c\145\x6e\147\x74\150") ? get_mo_option("\x6f\164\160\137\154\145\156\147\x74\150") : 5;
$iU = get_mo_option("\157\x74\x70\x5f\x76\x61\154\x69\x64\151\x74\x79") ? get_mo_option("\157\164\160\x5f\166\x61\x6c\151\x64\x69\164\x79") : 5;
$IQ = MoUtility::isMG();
$oD = $ec->getNonceValue();
include MOV_DIR . "\x76\151\x65\x77\x73\57\x6f\164\x70\163\145\x74\x74\151\156\x67\x73\56\x70\x68\x70";
