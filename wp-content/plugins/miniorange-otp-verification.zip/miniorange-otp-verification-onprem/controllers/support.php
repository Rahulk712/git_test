<?php


use OTP\Helper\MoConstants;
$current_user = wp_get_current_user();
$xX = get_mo_option("\141\144\x6d\x69\156\137\x65\155\x61\151\154");
$lr = get_mo_option("\x61\x64\155\x69\156\x5f\x70\150\157\x6e\145");
$lr = $lr ? $lr : '';
$N8 = MoConstants::FEEDBACK_EMAIL;
include MOV_DIR . "\x76\151\145\167\163\57\x73\165\x70\x70\x6f\162\164\56\x70\150\x70";
