<?php


use OTP\Helper\GatewayFunctions;
$Xk = GatewayFunctions::instance();
$Xk->showConfigurationPage($ke);
