<?php


include MOV_DIR . "\x76\151\145\167\x73\57\x6f\157\x70\x73\x2e\x70\x68\160";
