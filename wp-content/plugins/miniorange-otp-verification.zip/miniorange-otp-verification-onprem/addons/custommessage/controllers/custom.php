<?php


use OTP\Addons\CustomMessage\Handler\CustomMessages;
$zv = '';
$OX = "\143\165\163\x74\157\155\105\x6d\x61\151\x6c\115\163\x67\105\x64\x69\x74\157\162";
$u1 = array("\x6d\x65\144\x69\x61\137\142\x75\164\164\157\156\163" => false, "\x74\145\x78\x74\141\x72\145\x61\137\156\141\x6d\145" => "\x63\x6f\x6e\x74\x65\156\164", "\145\x64\151\x74\x6f\x72\x5f\x68\145\151\147\x68\164" => "\61\x37\60\160\170", "\x77\x70\141\165\164\x6f\160" => false);
$Sw = CustomMessages::instance();
$oD = $Sw->getNonceValue();
$xZ = admin_post_url();
include MCM_DIR . "\166\151\145\167\x73\57\x63\x75\x73\x74\x6f\x6d\x2e\160\150\160";
